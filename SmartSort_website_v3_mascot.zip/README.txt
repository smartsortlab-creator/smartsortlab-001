# SmartSort website

This version recreates the supplied SmartSort reference design and connects it to the supplied Teachable Machine model.

## Folder structure

- index.html
- style.css
- script.js
- my_model/model.json
- my_model/metadata.json
- my_model/weights.bin

## Run locally

Because browsers can block model files when opening index.html directly with file://, run a small local server.

Python:
    python -m http.server 8000

Then open:
    http://localhost:8000

## Netlify

Upload the whole folder as a Netlify site. No Python backend is required for the current logic: the Teachable Machine model runs in the browser, and the disposal/warning dictionaries are the JavaScript equivalent of the Python dictionaries supplied with the project.

## Important

The current model has 8 classes:
Plastic, Paper/Cardboard, Glass, Metal, Organic/Food, E-Waste, Hazardous Waste, General Waste.

The UI is intentionally close to the supplied reference screenshots:
- cream/off-white background
- dark teal typography
- editorial serif "Sorter"
- upload panel on the left
- probability panel on the right
- confidence/result card below
- low-confidence threshold at 70%
