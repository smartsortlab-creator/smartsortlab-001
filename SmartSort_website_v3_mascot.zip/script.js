const MODEL_URL = "./my_model/";

let model = null;
let selectedImage = null;

const disposal = {
  "Plastic": "Place in the appropriate plastic recycling stream.",
  "Paper/Cardboard": "Recycle if clean and dry.",
  "Glass": "Place in the appropriate glass recycling stream.",
  "Metal": "Place in the appropriate metal recycling stream.",
  "Organic/Food": "Place in the organic or composting stream where available.",
  "E-Waste": "Take it to an authorised e-waste collection point.",
  "Hazardous Waste": "Take it to a designated hazardous-waste collection facility.",
  "General Waste": "Place it in the appropriate general-waste bin."
};

const warnings = {
  "Plastic": "Check local recycling rules before disposal.",
  "Paper/Cardboard": "Food-soiled or wet paper may not be recyclable.",
  "Glass": "Broken glass: Handle with care to avoid injury.",
  "Metal": "Rusted or sharp metal objects should be handled carefully.",
  "Organic/Food": "Composting is preferred where available.",
  "E-Waste": "Do NOT place e-waste in normal household waste.",
  "Hazardous Waste": "Do NOT place hazardous waste in normal household bins.",
  "General Waste": "Consider whether the item can be reused or recycled first."
};

const fileInput = document.getElementById("fileInput");
const dropzone = document.getElementById("dropzone");
const preview = document.getElementById("preview");
const emptyState = document.getElementById("emptyState");
const previewState = document.getElementById("previewState");
const classifyBtn = document.getElementById("classifyBtn");
const modelStatus = document.getElementById("modelStatus");

fileInput.addEventListener("change", e => {
  if (e.target.files[0]) setImage(e.target.files[0]);
});

["dragenter","dragover"].forEach(type => {
  dropzone.addEventListener(type, e => {
    e.preventDefault();
    dropzone.style.background = "#eeeadf";
  });
});
["dragleave","drop"].forEach(type => {
  dropzone.addEventListener(type, e => {
    e.preventDefault();
    dropzone.style.background = "";
  });
});
dropzone.addEventListener("drop", e => {
  if (e.dataTransfer.files[0]) setImage(e.dataTransfer.files[0]);
});

function setImage(file) {
  if (!file.type.startsWith("image/")) return;
  selectedImage = file;
  const url = URL.createObjectURL(file);
  preview.src = url;
  emptyState.classList.add("hidden");
  previewState.classList.remove("hidden");
  classifyBtn.disabled = !model;
}

async function loadModel() {
  try {
    model = await tmImage.load(MODEL_URL + "model.json", MODEL_URL + "metadata.json");
    document.getElementById("classCount").textContent = model.getTotalClasses() + " classes";
    modelStatus.textContent = "AI MODEL READY · PROCESSED IN YOUR BROWSER";
    if (selectedImage) classifyBtn.disabled = false;
  } catch (err) {
    console.error(err);
    modelStatus.textContent = "MODEL NOT LOADED · CHECK THE my_model FOLDER";
  }
}

classifyBtn.addEventListener("click", async () => {
  if (!model || !selectedImage) return;

  classifyBtn.disabled = true;
  classifyBtn.textContent = "Classifying…";

  const img = new Image();
  img.src = URL.createObjectURL(selectedImage);
  await new Promise(resolve => img.onload = resolve);

  try {
    const predictions = await model.predict(img);
    predictions.sort((a,b) => b.probability - a.probability);
    renderProbabilities(predictions);

    const top = predictions[0];
    renderTopResult(top.className, top.probability * 100);
  } catch (err) {
    console.error(err);
    alert("Could not classify this image. Please try another image.");
  } finally {
    classifyBtn.disabled = false;
    classifyBtn.innerHTML = 'Classify this item <span>→</span>';
  }
});

function renderProbabilities(predictions) {
  const box = document.getElementById("probabilities");
  box.innerHTML = predictions.map((p, i) => {
    const value = (p.probability * 100).toFixed(1);
    return `
      <div class="prob-row">
        <div class="prob-head">
          <span class="name">${escapeHtml(p.className)}</span>
          <span class="value">${value}%</span>
        </div>
        <div class="track"><div class="fill" style="width:${value}%"></div></div>
      </div>
    `;
  }).join("");
}

function renderTopResult(label, confidence) {
  document.getElementById("topResult").classList.remove("hidden");
  document.getElementById("topLabel").textContent = label;
  document.getElementById("topConfidence").textContent = confidence.toFixed(1) + "%";
  document.getElementById("topBar").style.width = confidence + "%";

  if (confidence < 70) {
    document.getElementById("disposalText").textContent = "Please upload a clearer image.";
    document.getElementById("warningText").textContent = "AI confidence is too low to give reliable disposal guidance.";
  } else if (disposal[label]) {
    document.getElementById("disposalText").textContent = disposal[label];
    document.getElementById("warningText").textContent = warnings[label];
  } else {
    document.getElementById("disposalText").textContent = "Please check the AI prediction.";
    document.getElementById("warningText").textContent = "Unknown waste category.";
  }
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

loadModel();
